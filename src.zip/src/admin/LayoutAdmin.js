import { Outlet } from "react-router-dom";
import { Helmet } from "react-helmet"
import AdminHeader from "./AdminHeader";
import AdminFooter from "./AdminFooter";
import './plugins/fontawesome-free/css/all.min.css';
import './plugins/overlayScrollbars/css/OverlayScrollbars.min.css';
import './dist/css/adminlte.min.css';
import AdminSidebar from "./AdminSidebar";
function Layoutadmin()
{
    return(<div class="wrapper">
        <AdminHeader />
        <AdminSidebar />
        <Outlet />
       
        <AdminFooter/>
        <Helmet>
        <script src="plugins/jquery/jquery.min.js"></script>
        <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
        <script src="dist/js/adminlte.js"></script>
        <script src="plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
        <script src="plugins/raphael/raphael.min.js"></script>
        <script src="plugins/jquery-mapael/jquery.mapael.min.js"></script>
        <script src="plugins/jquery-mapael/maps/usa_states.min.js"></script>
        <script src="plugins/chart.js/Chart.min.js"></script>
        <script src="dist/js/demo.js"></script>
        <script src="dist/js/pages/dashboard2.js"></script>
      </Helmet>
    </div>)
}
export default Layoutadmin;