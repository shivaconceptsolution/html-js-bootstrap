function A()
{
   
    return(<>
        <h1>A Component </h1>
       <B name="welcom in scs"/>
    </>)
}
function B(props)
{
  const data = props.name
   return(<div>
    <h1>B Component</h1>
    <p>{props.name}</p>
    <C  name={data} />
   </div>)
}
function C(props)
{
    
   return(<div>
    <h1>C Component Hello {props.name}</h1>
   </div>)
}
export default A;