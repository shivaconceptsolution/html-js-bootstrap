
export const addNumber = (number) => {
    return {
      type: 'ADD',
      payload: number,
    };
  };