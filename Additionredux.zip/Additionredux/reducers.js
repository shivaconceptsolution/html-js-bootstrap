import { combineReducers } from 'redux';
const initialState = {
    sum: 0,
  };
  const sumReducer = (state = initialState.sum, action) => {
    switch (action.type) {
      case 'ADD':
        return state + action.payload;
      default:
        return state;
    }
  };  

  const rootReducer = combineReducers({
    sum: sumReducer,
  });

  export default rootReducer;